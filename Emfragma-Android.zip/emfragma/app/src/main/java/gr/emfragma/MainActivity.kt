package gr.emfragma

import android.Manifest
import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.location.Location
import android.location.LocationManager
import android.net.Uri
import android.os.Bundle
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient

class MainActivity : Activity() {

    private lateinit var webView: WebView
    private var pendingNumber: String? = null
    private var pendingText: String? = null

    /** Γέφυρα προς τη σελίδα. Η σελίδα είναι τοπική και δεν φορτώνει τίποτα από το internet. */
    inner class Bridge {
        @JavascriptInterface
        fun sendSms(number: String, text: String, withLocation: Boolean) {
            runOnUiThread { handleSms(number, text, withLocation) }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Κρατά την οθόνη αναμμένη όσο η εφαρμογή είναι ανοιχτή (χρήσιμο σε έκτακτη ανάγκη)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        webView = WebView(this)
        webView.setBackgroundColor(Color.TRANSPARENT)
        setContentView(webView)

        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true            // για την Κάρτα έκτακτης ανάγκης (localStorage)
            allowFileAccess = false
            allowContentAccess = false
            cacheMode = WebSettings.LOAD_NO_CACHE
        }
        webView.addJavascriptInterface(Bridge(), "AndroidApp")

        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val uri: Uri = request.url
                if (uri.scheme == "tel") {
                    try {
                        startActivity(Intent(Intent.ACTION_DIAL, uri))
                    } catch (e: ActivityNotFoundException) {
                        // Συσκευή χωρίς εφαρμογή κλήσεων: δεν κάνουμε τίποτα
                    }
                }
                // Όλα τα υπόλοιπα links μπλοκάρονται: η εφαρμογή λειτουργεί εντελώς offline
                return true
            }
        }

        if (savedInstanceState == null) {
            webView.loadUrl("file:///android_asset/index.html")
        } else {
            webView.restoreState(savedInstanceState)
        }
    }

    private fun handleSms(number: String, text: String, withLocation: Boolean) {
        val clean = number.filter { it.isDigit() || it == '+' }
        if (clean.isEmpty()) return
        if (withLocation && !hasLocationPermission()) {
            pendingNumber = clean
            pendingText = text
            requestPermissions(
                arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION),
                REQ_LOCATION
            )
            return
        }
        openSms(clean, text, withLocation)
    }

    private fun hasLocationPermission(): Boolean =
        checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
            checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED

    private fun lastLocation(): Location? {
        if (!hasLocationPermission()) return null
        val lm = getSystemService(Context.LOCATION_SERVICE) as LocationManager
        var best: Location? = null
        for (provider in lm.getProviders(true)) {
            val l = try {
                lm.getLastKnownLocation(provider)
            } catch (e: SecurityException) {
                null
            } ?: continue
            if (best == null || l.time > best.time) best = l
        }
        return best
    }

    private fun openSms(number: String, text: String, withLocation: Boolean) {
        var body = text
        if (withLocation) {
            val loc = lastLocation()
            body += if (loc != null) {
                "\nΤοποθεσία: https://maps.google.com/?q=${loc.latitude},${loc.longitude}"
            } else {
                "\n(Η τοποθεσία δεν ήταν διαθέσιμη. Άνοιξε το GPS.)"
            }
        }
        val intent = Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:$number")).putExtra("sms_body", body)
        try {
            startActivity(intent) // Ανοίγει το μήνυμα έτοιμο, ο χρήστης πατά αποστολή
        } catch (e: ActivityNotFoundException) {
            // Δεν υπάρχει εφαρμογή μηνυμάτων
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQ_LOCATION) {
            val n = pendingNumber
            val t = pendingText
            pendingNumber = null
            pendingText = null
            if (n != null && t != null) openSms(n, t, hasLocationPermission())
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        webView.saveState(outState)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        // Η σελίδα γυρίζει στην αρχική οθόνη. Από την αρχική κλείνει η εφαρμογή.
        webView.evaluateJavascript("appBack()") { result ->
            if (result != "true") finish()
        }
    }

    companion object {
        private const val REQ_LOCATION = 1
    }
}
