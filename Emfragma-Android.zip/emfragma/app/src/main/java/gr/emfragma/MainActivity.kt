package gr.emfragma

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.WindowManager
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient

class MainActivity : Activity() {

    private lateinit var webView: WebView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Κρατά την οθόνη αναμμένη όσο η εφαρμογή είναι ανοιχτή (χρήσιμο σε έκτακτη ανάγκη)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        webView = WebView(this)
        webView.setBackgroundColor(Color.TRANSPARENT)
        setContentView(webView)

        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true            // για την Κάρτα έκτακτης ανάγκης (localStorage)
            allowFileAccess = false
            allowContentAccess = false
            cacheMode = WebSettings.LOAD_NO_CACHE
        }

        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val uri: Uri = request.url
                return if (uri.scheme == "tel") {
                    try {
                        startActivity(Intent(Intent.ACTION_DIAL, uri))
                    } catch (e: ActivityNotFoundException) {
                        // Συσκευή χωρίς εφαρμογή κλήσεων: δεν κάνουμε τίποτα
                    }
                    true
                } else {
                    // Όλα τα υπόλοιπα links μπλοκάρονται: η εφαρμογή λειτουργεί εντελώς offline
                    true
                }
            }
        }

        if (savedInstanceState == null) {
            webView.loadUrl("file:///android_asset/index.html")
        } else {
            webView.restoreState(savedInstanceState)
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        webView.saveState(outState)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }
}
